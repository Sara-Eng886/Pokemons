
fetch("https://pokeapi.co/api/v2/pokemon/ditto")
    .then(response => {
       
    })
    .catch(error => {
        
    });